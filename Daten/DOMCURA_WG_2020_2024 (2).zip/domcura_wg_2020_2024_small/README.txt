DOMCURA – Wohngebäude (synthetisch), 2020–2024, EUR-ähnliche Werte. Enthält Kern-CSV-Dateien und abgeleitete Analysen.
